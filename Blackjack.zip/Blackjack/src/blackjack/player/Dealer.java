package blackjack.player;

public class Dealer extends Person{

}
